<template>
  <div class="p-4 bg-gray-900 rounded-xl text-white space-y-3">
    <h3 class="font-semibold text-lg">🧠 Eigenen Algorithmus schreiben</h3>

    <textarea
      v-model="userCode"
      class="w-full h-48 p-2 font-mono bg-gray-800 rounded-md"
      placeholder="// Schreibe hier deinen Algorithmus..."
    ></textarea>

    <div class="flex items-center justify-between">
      <select v-model="lang" class="bg-gray-800 rounded-lg p-2">
        <option value="typescript">TypeScript</option>
        <option value="javascript">JavaScript</option>
      </select>

      <button
        @click="loadCustomPolicy"
        class="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg"
      >
        Laden & Verwenden
      </button>
    </div>

    <div v-if="status" :class="statusClass" class="p-2 rounded-lg">
      {{ status }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from "vue";
import { CustomPolicyLoader } from "src/algorithms/CustomPolicyLoader";
const emit = defineEmits(["policyLoaded"]);

const userCode = ref(`import { BasePolicy } from "./BasePolicy";
export class MyPolicy extends BasePolicy {
  selectAction() {
    return Math.floor(this.rng() * this.env.arms.length);
  }
}`);
const lang = ref<"typescript" | "javascript">("typescript");
const status = ref<string | null>(null);

const loadCustomPolicy = () => {
  try {
    const policy = CustomPolicyLoader.loadPolicy(userCode.value, lang.value);
    emit("policyLoaded", policy);
    status.value = `✅ Policy "${policy.constructor.name}" erfolgreich geladen!`;
  } catch (err: any) {
    status.value = `❌ Fehler: ${err.message}`;
  }
};

const statusClass = computed(() =>
  status.value?.startsWith("✅")
    ? "bg-green-800 text-green-200"
    : "bg-red-800 text-red-200",
);
</script>
