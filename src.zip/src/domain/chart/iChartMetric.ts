// Welche Kennzahl wollen wir im Verlauf plotten?
export type ChartMetric = "cumReward" | "avgReward" | "regret" | "bestRate";
