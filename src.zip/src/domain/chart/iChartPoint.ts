// ein einzelner Punkt auf der X-Achse (Schritt) mit Y-Wert
export interface iChartPoint {
  step: number;
  y: number;
}
